// Bounded SERP validation of representative landing-page queries.
// Saved credential used exclusively against the documented Yandex API endpoint.
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url));
process.loadEnvFile('/etc/wordstat-api.env');
const apiKey=(process.env.WORDSTAT_API_KEY||process.env.YANDEX_SEARCH_API_KEY||'').trim();
const folderId=(process.env.WORDSTAT_FOLDER_ID||process.env.YANDEX_FOLDER_ID||'').trim();
if(!apiKey||!folderId)throw Error('Search credentials missing');
const probes=[
['HOME','программа для мастерской'],
['HOME','программа для малого производства'],
['HOME','учет в мастерской'],
['COST_SOFT','программа для расчета себестоимости'],
['COST_SOFT','программа для расчета себестоимости продукции'],
['COST_SOFT','программа для учета себестоимости'],
['CALC_COST','калькулятор себестоимости'],
['CALC_COST','калькулятор себестоимости продукции'],
['COST_GUIDE','расчет себестоимости продукции'],
['COST_GUIDE','себестоимость изделия'],
['ACCOUNT_GUIDE','учет себестоимости продукции'],
['STOCK','программа учета материалов'],
['STOCK','учет материалов на производстве'],
['PRODUCTION','программа учета производства'],
['PRODUCTION','учет производства продукции'],
['FINANCE','учет себестоимости и прибыли'],
['PRICE_GUIDE','как рассчитать цену изделия'],
['CRAFT','как рассчитать стоимость ручной работы'],
['CRAFT','стоимость ручной работы'],
['CONFECTIONER','программа для кондитера'],
['CAKE','калькулятор себестоимости торта'],
['AMBIG','калькулятор торта'],
['AMBIG','калькулятор кондитера'],
['FOOD','калькулятор себестоимости блюда'],
['FOOD','калькуляция блюд'],
['CANDLE','калькулятор себестоимости свечи'],
['AMBIG','калькулятор свечей'],
['SOAP','калькулятор себестоимости мыла'],
['PRINT_GUIDE','себестоимость 3д печати'],
['PRINT_CALC','калькулятор стоимости 3д печати'],
['MARKUP','калькулятор наценки'],
['MARKUP','калькулятор маржинальности'],
['PROFIT_CALC','калькулятор прибыли'],
['PROFIT_CALC','калькулятор рентабельности'],
['BREAKEVEN','калькулятор точки безубыточности'],
['PRICE_CALC','калькулятор цены изделия'],
['FOOD_SOFT','программа для расчета себестоимости блюд'],
['ACCOUNT_GUIDE','управленческий учет себестоимости продукции'],
['HOME','программа учета для мастера'],
['STOCK','учет материалов для мастера'],
['CRAFT','калькулятор стоимости ручной работы']
];
let cursor=0;
const all=[];
async function worker(){
 while(cursor<probes.length){
  const [cluster,phrase]=probes[cursor++];
  const file=root+'raw/serp-'+createHash('sha256').update(phrase).digest('hex').slice(0,16)+'.json';
  let r;
  if(existsSync(file))r=JSON.parse(readFileSync(file,'utf8'));
  if(!r?.ok){
   await new Promise(resolve=>setTimeout(resolve,1400));
   const start=Date.now();
   try{
    const response=await fetch('https://searchapi.api.cloud.yandex.net/v2/web/search',{
     method:'POST',redirect:'error',signal:AbortSignal.timeout(30_000),
     headers:{'Content-Type':'application/json',Authorization:'Api-Key '+apiKey},
     body:JSON.stringify({query:{searchType:'SEARCH_TYPE_RU',queryText:phrase,familyMode:'FAMILY_MODE_MODERATE',page:0},groupSpec:{groupMode:'GROUP_MODE_FLAT',groupsOnPage:10,docsInGroup:1},region:'225',l10n:'LOCALIZATION_RU',folderId,responseFormat:'FORMAT_XML',maxPassages:1})
    });
    if(!response.ok){await response.body?.cancel().catch(()=>{});r={ok:false,http:response.status};if(response.status===429)await new Promise(resolve=>setTimeout(resolve,8000));}
    else{
     const j=await response.json();
     r={ok:typeof j.rawData==='string',http:response.status,xml:typeof j.rawData==='string'?Buffer.from(j.rawData,'base64').toString('utf8'):''};
    }
   }catch(e){r={ok:false,error:e.name};}
   r={...r,cluster,phrase,received_utc:new Date().toISOString(),elapsed_ms:Date.now()-start,region:'225',top:10};
   writeFileSync(file,JSON.stringify(r,null,2));
  }
  all.push(r);console.log(r.cluster,r.phrase,r.http??r.error,r.ok?'OK':'FAIL',r.elapsed_ms??'');
 }
}
await worker();
writeFileSync(root+'serp_results.json',JSON.stringify(all,null,2));
console.log('TOTAL',all.length,'HTTP OK',all.filter(x=>x.ok).length);
