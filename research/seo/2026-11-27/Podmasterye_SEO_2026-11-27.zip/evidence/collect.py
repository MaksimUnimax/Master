"""Wordstat research. Use installed client; credentials remain in its config.
Region 225 (Russia), DEVICE_ALL. Do not use association frequencies as exact.
"""
import json,subprocess,time,datetime,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
BASE=Path(__file__).parent
CLIENT="/opt/wordstat-standalone/wordstat.mjs"
EXPAND={
"service":["программа учета производства","программа для малого производства","учет малого производства","программа для мастерской","учет в мастерской","программа учета для рукоделия","программа учета себестоимости","сервис учета производства","программа для расчета стоимости изделий","программа для расчета себестоимости"],
"materials":["учет материалов на производстве","учет материалов в мастерской","программа учета материалов","учет сырья и материалов","учет остатков материалов","учет готовой продукции и материалов","программа складского учета для производства"],
"production":["учет производства продукции","учет производства изделий","учет рецептур","учет расхода материалов на изделие","технологическая карта изделия","планирование закупок материалов"],
"finance":["учет доходов и расходов производства","учет прибыли мастерской","учет продаж изделий","учет заказов мастера","учет расходов мастерской","учет себестоимости и прибыли"],
"pricing":["расчет цены изделия","расчет цены продажи изделия","калькулятор стоимости изделия","расчет себестоимости изделия","расчет себестоимости ручной работы","расчет себестоимости товара"],
"niches":["программа учета для мастеров ручной работы","программа для кондитера учет","учет производства свечей","учет швейного производства","программа учета 3д печати","учет материалов для украшений"]
}
def call(task):
 kind,group,phrase=task
 # Re-run only missing files, preserve provider responses.
 import hashlib
 uid=hashlib.sha256((kind+"\0"+phrase).encode()).hexdigest()[:16]
 path=BASE/"raw"/f"{kind}-{uid}.json"
 if path.exists():
  previous=json.loads(path.read_text())
  if previous.get("ok"):return previous
 cmd={"method":"getTop","phrase":phrase,"numPhrases":60 if kind=="expand" else 1,"regions":["225"],"devices":["DEVICE_ALL"]}
 start=time.monotonic()
 try:
  p=subprocess.run(["node",CLIENT],input=json.dumps(cmd,ensure_ascii=False),text=True,capture_output=True,timeout=38)
  if p.returncode:
   result={"ok":False,"error":p.stderr.strip()[:180]}
  else:
   j=json.loads(p.stdout)
   if not isinstance(j,dict):raise ValueError("unexpected response")
   result={"ok":True,"result":j}
 except Exception as e:
  result={"ok":False,"error":type(e).__name__}
 result.update(kind=kind,group=group,phrase=phrase,command=cmd,received_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=round(time.monotonic()-start,2))
 path.write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(kind,group,phrase, result.get("result",{}).get("totalCount","ERROR"),len(result.get("result",{}).get("results",[])),flush=True)
 return result
if __name__=="__main__":
 kind=sys.argv[1]
 tasks=[(kind,g,p) for g,phrases in EXPAND.items() for p in phrases] if kind=="expand" else [(kind,r["cluster"],r["operator"]) for r in json.loads((BASE/"exact_requests.json").read_text())]
 with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(call,tasks))
 (BASE/f"{kind}_results.json").write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print("TOTAL",kind,len(results),"OK",sum(r["ok"] for r in results),flush=True)
